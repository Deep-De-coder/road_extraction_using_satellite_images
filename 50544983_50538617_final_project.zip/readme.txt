First you need to access dataset using kaggle api
dataset link: https://www.kaggle.com/datasets/balraj98/deepglobe-road-extraction-dataset 
since dataset is large we are providing the .ipynb files with saved output and also explained the overall process in the report. 
Since we ran code on Google colab we entered the path according to that for the running purpose you need to change the path first.

After attaching pickle file zip is geeting larger than 2GB hence we are attaching a link of google drive folder which contains all the pickle files.
https://drive.google.com/drive/folders/1VuYdE9l5sFM9tG18ZTDH_ruD0UeMbg3b?usp=sharing